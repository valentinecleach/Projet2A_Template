from src.Webservice.API import run_app

# Lancement seulement si le fichier est exécuté directement
if __name__ == "__main__":
    run_app()