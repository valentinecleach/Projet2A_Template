# UTILITE??


def test_fill_table_user():
    pass


def test_fill_table_movie():
    pass


def test_fill_table_follower():
    pass


def test_fill_table_favorite():
    pass
