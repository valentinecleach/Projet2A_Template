#### FOR RATING ####
def test_get_overall_rating():
    pass


def test_get_ratings_user():
    pass


def test_delete_user_and_update_ratings():
    pass


def test_delete_a_user_rating():
    pass


def test_count_rating():
    pass


def test_updating_rating_of_movie():
    pass


def test_rate_film_or_update():
    pass


#### FOR COMMENT ####
def test_add_or_update_comment():
    pass


def test_get_comments_user():
    pass


def test_delete_a_user_comment():
    pass
